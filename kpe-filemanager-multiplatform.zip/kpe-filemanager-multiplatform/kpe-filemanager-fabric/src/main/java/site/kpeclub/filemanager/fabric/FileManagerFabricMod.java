package site.kpeclub.filemanager.fabric;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.DedicatedServerModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import site.kpeclub.filemanager.core.ConsoleManager;
import site.kpeclub.filemanager.core.SimpleYamlConfig;
import site.kpeclub.filemanager.core.TokenManager;
import site.kpeclub.filemanager.core.WebServer;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Fabric launcher for the same core (WebServer, handlers, TokenManager,
 * ConsoleManager) the Paper/Velocity/Forge modules use — see
 * kpe-filemanager-core.
 * <p>
 * IMPORTANT — rewritten for Minecraft 26.1+: as of Minecraft 26.1, Fabric
 * dropped Yarn mappings entirely (the game is now unobfuscated and uses
 * Mojang's official class/method names directly). This version targets
 * that: vanilla classes here match the same official names already used in
 * the Forge module (ServerPlayer, CommandSourceStack, Component, etc.),
 * not the old Yarn names (ServerPlayerEntity, ServerCommandSource, Text).
 * If you're building against Minecraft 1.21.11 or earlier instead, you
 * need the old Yarn-mapped names back — see git history / ask for that
 * version specifically.
 * <p>
 * Verified NOT renamed in the 26.1 Fabric API migration (checked against
 * the official porting guide): CommandRegistrationCallback,
 * ServerLifecycleEvents.SERVER_STARTED/SERVER_STOPPING. Still unverified:
 * exact Fabric Loom / Fabric Loader version numbers in build.gradle — the
 * page listing current recommended versions requires JavaScript to render
 * and couldn't be read from here. Check https://fabricmc.net/develop/ in
 * an actual browser if the build fails on version resolution.
 * <p>
 * Fabric has no built-in fine-grained permission system — this uses the
 * vanilla operator permission level (4, same as /op, /stop) for both
 * kpe.filemanager.access and kpe.filemanager.reload. Integrate a
 * permissions mod (LuckPerms for Fabric, fabric-permissions-api) if you
 * want separate, grantable nodes instead.
 */
public class FileManagerFabricMod implements DedicatedServerModInitializer {

    private static final int OP_LEVEL = 4;

    private WebServer webServer;
    private TokenManager tokenManager;
    private ConsoleManager consoleManager;
    private ScheduledExecutorService scheduler;
    private MinecraftServer minecraftServer;
    private File dataFolder;

    private volatile String publicUrlBase;
    private volatile int port;
    private volatile boolean httpsEnabled;

    @Override
    public void onInitializeServer() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            this.minecraftServer = server;
            this.dataFolder = new File(server.getRunDirectory(), "kpefilemanager");
            this.webServer = new WebServer();
            this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "kpe-filemanager-scheduler");
                t.setDaemon(true);
                return t;
            });
            startServices(null);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (webServer != null) webServer.stop();
            if (consoleManager != null) consoleManager.stop();
            if (scheduler != null) scheduler.shutdownNow();
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("filemgr")
                    .executes(ctx -> runFilemgr(ctx.getSource(), new String[0]))
                    .then(Commands.argument("args", StringArgumentType.greedyString())
                            .executes(ctx -> runFilemgr(ctx.getSource(),
                                    StringArgumentType.getString(ctx, "args").split("\\s+")))));
            dispatcher.register(Commands.literal("fm")
                    .executes(ctx -> runFilemgr(ctx.getSource(), new String[0]))
                    .then(Commands.argument("args", StringArgumentType.greedyString())
                            .executes(ctx -> runFilemgr(ctx.getSource(),
                                    StringArgumentType.getString(ctx, "args").split("\\s+")))));
        });
    }

    private int runFilemgr(CommandSourceStack source, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!source.hasPermission(OP_LEVEL)) {
                source.sendFailure(Component.literal("You do not have permission to reload the file manager."));
                return 0;
            }
            source.sendSuccess(() -> Component.literal("Reloading file manager config...").withStyle(ChatFormatting.GRAY), false);
            scheduler.execute(() -> startServices(source));
            return 1;
        }

        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal(
                    "This command can only be used by a connected player. Use '/filemgr reload' from console to reload config."));
            return 0;
        }
        if (tokenManager == null) {
            source.sendFailure(Component.literal("The file manager is not ready yet, try again in a moment."));
            return 0;
        }
        if (!source.hasPermission(OP_LEVEL)) {
            source.sendFailure(Component.literal("You do not have permission to use the file manager."));
            return 0;
        }

        String token = tokenManager.generateLoginToken(player.getUUID(), player.getGameProfile().getName());
        String url = resolveBaseUrl() + "/?token=" + token;

        source.sendSuccess(() -> Component.literal("Your one-time file manager link (expires in a few minutes):")
                .withStyle(ChatFormatting.AQUA), false);
        source.sendSuccess(() -> Component.literal(url).withStyle(ChatFormatting.GREEN)
                .withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url))), false);
        return 1;
    }

    /** Same reload-without-restart approach as the other modules. */
    private boolean startServices(CommandSourceStack feedbackTo) {
        SimpleYamlConfig config;
        Path configPath = dataFolder.toPath().resolve("config.yml");
        try {
            Files.createDirectories(dataFolder.toPath());
            if (!Files.exists(configPath)) {
                try (var in = getClass().getResourceAsStream("/config.yml")) {
                    if (in != null) Files.copy(in, configPath);
                }
            }
            config = SimpleYamlConfig.load(configPath);
        } catch (Exception e) {
            System.err.println("[KPEFileManager] Failed to load config.yml: " + e.getMessage());
            config = new SimpleYamlConfig();
        }

        port = config.getInt("port", 8080);
        String bindAddress = config.getString("bind-address", "0.0.0.0");
        String rootDirConfig = config.getString("root-directory", "");
        long tokenExpiryMinutes = config.getLong("token-expiry-minutes", 5);
        long sessionExpiryHours = config.getLong("session-expiry-hours", 12);
        long maxEditFileSizeKb = config.getLong("max-edit-file-size-kb", 20480000);
        long maxUploadSizeMb = config.getLong("max-upload-size-mb", 512);
        int consoleMaxLines = config.getInt("console.max-lines", 400);
        String loginPassword = config.getString("login-password", "");
        publicUrlBase = config.getString("public-url", "");

        httpsEnabled = config.getBoolean("https.enabled", false);
        String keystorePathConfig = config.getString("https.keystore-path", "keystore.jks");
        String keystorePassword = config.getString("https.keystore-password", "");
        String keyPassword = config.getString("https.key-password", "");
        File keystoreFile = new File(keystorePathConfig);
        if (!keystoreFile.isAbsolute()) {
            keystoreFile = new File(dataFolder, keystorePathConfig);
        }

        File serverRoot = new File(System.getProperty("user.dir"));
        File root = rootDirConfig == null || rootDirConfig.isBlank()
                ? serverRoot
                : new File(serverRoot, rootDirConfig);
        if (!root.exists()) {
            root.mkdirs();
        }

        if (tokenManager == null) {
            tokenManager = new TokenManager(tokenExpiryMinutes, sessionExpiryHours);
        } else {
            tokenManager.updateExpiries(tokenExpiryMinutes, sessionExpiryHours);
        }

        if (consoleManager == null) {
            consoleManager = new ConsoleManager(
                    dataFolder,
                    consoleMaxLines,
                    (task, initialDelayMs, periodMs) -> scheduler.scheduleAtFixedRate(
                            task, initialDelayMs, periodMs, TimeUnit.MILLISECONDS),
                    // Dispatching a command touches game state, so it must run on the
                    // server thread — MinecraftServer#execute() queues it for next tick.
                    cmd -> minecraftServer.execute(() ->
                            minecraftServer.getCommands().performPrefixedCommand(
                                    minecraftServer.createCommandSourceStack(), cmd)),
                    msg -> System.err.println("[KPEFileManager] " + msg));
            consoleManager.start();
        } else {
            consoleManager.setMaxLines(consoleMaxLines);
        }

        try {
            webServer.start(bindAddress, port, root, tokenManager, sessionExpiryHours, maxEditFileSizeKb,
                    consoleManager, httpsEnabled, keystoreFile, keystorePassword, keyPassword, maxUploadSizeMb,
                    loginPassword);
            String summary = (httpsEnabled ? "https://" : "http://") + bindAddress + ":" + port
                    + " (root: " + root.getPath() + ")";
            System.out.println("[KPEFileManager] web server listening on " + summary);
            if (feedbackTo != null) {
                feedbackTo.sendSuccess(() -> Component.literal("File manager config reloaded — now serving " + summary)
                        .withStyle(ChatFormatting.GREEN), false);
            }
            return true;
        } catch (Exception e) {
            System.err.println("[KPEFileManager] Failed to start web server: " + e.getMessage());
            if (feedbackTo != null) {
                feedbackTo.sendFailure(Component.literal("Reload failed: " + e.getMessage()));
            }
            return false;
        }
    }

    private String resolveBaseUrl() {
        String defaultScheme = httpsEnabled ? "https://" : "http://";
        if (publicUrlBase != null && !publicUrlBase.isBlank()) {
            String base = publicUrlBase.trim();
            if (!base.startsWith("http://") && !base.startsWith("https://")) {
                base = defaultScheme + base;
            }
            return base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        }
        try {
            String host = InetAddress.getLocalHost().getHostAddress();
            return defaultScheme + host + ":" + port;
        } catch (UnknownHostException e) {
            return defaultScheme + "localhost:" + port;
        }
    }
}
