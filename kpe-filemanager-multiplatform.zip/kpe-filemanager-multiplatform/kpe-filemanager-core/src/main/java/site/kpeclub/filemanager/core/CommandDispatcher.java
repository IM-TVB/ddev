package site.kpeclub.filemanager.core;

/** Executes a command as whatever this platform's console/admin sender is. */
public interface CommandDispatcher {
    void dispatch(String command);
}
