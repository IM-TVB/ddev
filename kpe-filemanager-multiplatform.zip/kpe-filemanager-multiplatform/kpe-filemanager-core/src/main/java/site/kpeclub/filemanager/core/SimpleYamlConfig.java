package site.kpeclub.filemanager.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Tiny hand-rolled reader for the flat / one-level-nested YAML subset this
 * plugin's config.yml actually uses (simple `key: value` pairs, one level
 * of indentation for blocks like `https:` / `console:`, "#" comments,
 * optionally-quoted string values). Not a general YAML parser — Velocity
 * doesn't ship one, and pulling in snakeyaml as a dependency just for a
 * dozen settings isn't worth it when core deliberately has zero deps.
 */
public class SimpleYamlConfig {

    private final Map<String, String> flat = new LinkedHashMap<>();

    public static SimpleYamlConfig load(Path path) throws IOException {
        SimpleYamlConfig cfg = new SimpleYamlConfig();
        if (!Files.exists(path)) return cfg;

        String currentSection = null;
        for (String rawLine : Files.readAllLines(path)) {
            String line = stripComment(rawLine);
            if (line.isBlank()) continue;

            int indent = 0;
            while (indent < line.length() && line.charAt(indent) == ' ') indent++;
            String content = line.substring(indent).trim();

            int colon = content.indexOf(':');
            if (colon < 0) continue;
            String key = content.substring(0, colon).trim();
            String value = content.substring(colon + 1).trim();

            if (indent == 0) {
                if (value.isEmpty()) {
                    currentSection = key;
                } else {
                    currentSection = null;
                    cfg.flat.put(key, unquote(value));
                }
            } else if (currentSection != null) {
                cfg.flat.put(currentSection + "." + key, unquote(value));
            }
        }
        return cfg;
    }

    private static String stripComment(String line) {
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') inQuotes = !inQuotes;
            if (c == '#' && !inQuotes) return line.substring(0, i);
        }
        return line;
    }

    private static String unquote(String v) {
        if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) {
            return v.substring(1, v.length() - 1);
        }
        return v;
    }

    public String getString(String key, String def) {
        return flat.getOrDefault(key, def);
    }

    public boolean getBoolean(String key, boolean def) {
        String v = flat.get(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    public long getLong(String key, long def) {
        String v = flat.get(key);
        if (v == null) return def;
        try {
            return Long.parseLong(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public int getInt(String key, int def) {
        return (int) getLong(key, def);
    }
}
