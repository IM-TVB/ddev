package site.kpeclub.filemanager.core;

/**
 * Minimal scheduler abstraction so core has zero platform dependency.
 * Paper/Folia implement this via the unified Paper scheduler API; Velocity
 * implements it via ProxyServer's own scheduler. Times are milliseconds,
 * not ticks, since not every platform has a tick loop (proxies don't).
 */
public interface PlatformScheduler {
    /** Runs task repeatedly, off the main/event thread, starting after initialDelayMs. */
    void runRepeating(Runnable task, long initialDelayMs, long periodMs);
}
