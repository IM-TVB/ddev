# KPE File Manager

A web-based server admin panel — file manager, live console, command
history — gated behind an in-game/proxy OP command. Styled like
Pterodactyl, self-contained, no external panel required.

**Version 1.0.2**

## Supported platforms

| Platform | Module | Status |
|---|---|---|
| Paper | `kpe-filemanager-paper` | Fully supported, Maven, build-verified over many iterations |
| Folia | `kpe-filemanager-paper` (same jar) | Fully supported |
| Velocity | `kpe-filemanager-velocity` | Written correctly per docs, Maven — unverified, see note below |
| Fabric | `kpe-filemanager-fabric` | Written correctly per docs, **Gradle** — higher-risk, see note below |
| Forge | `kpe-filemanager-forge` | Written correctly per docs, **Gradle** — higher-risk, see note below |
| BungeeCord | — | Not built yet |
| Sponge | — | Not built yet |

**Unverified note (Velocity):** written against the documented Velocity 3.4.0
API and reviewed carefully, but this environment has no network access to
Maven Central or PaperMC's repo, so it has never actually been compiled or
run against a real Velocity proxy. Build it (`mvn package` from a machine
with normal internet access) and test it before relying on it. If `mvn`
reports errors, they're almost certainly quick fixes — wrong method name,
wrong package for a class — rather than anything structural.

**Higher-risk note (Fabric/Forge):** these needed a fundamentally different
build tool than everything else in this project. Paper and Velocity are
both plain Maven — drop a dependency, compile, done. Fabric and Forge run
directly against Minecraft's own (obfuscated) code, so they require Gradle
with a special plugin (Fabric Loom / ForgeGradle) that downloads Minecraft
itself and deobfuscates it against a mappings file before your code can
even compile against it. That tooling has no Maven equivalent, and neither
module has been built or run even once — the `build.gradle` files are a
best-effort based on current documented conventions, not something proven
to work. Concretely expect: version numbers (Loom/ForgeGradle version,
Minecraft version, Yarn mappings version, Fabric API version, Forge
version) that may need bumping to match whatever you actually target, and
possibly a method name or two that's shifted since — Fabric's Yarn mappings
and Forge's API both change across Minecraft versions in ways Velocity's
API doesn't. Both also lack Bukkit-style permission defaults entirely —
`kpe.filemanager.access`/`reload` map to vanilla operator permission level 4
(same level required for `/op`, `/stop`), not separately-grantable nodes,
unless you wire in a permissions mod yourself.

**Fabric-specific:** the `kpe-filemanager-fabric` module targets Minecraft
**26.1+** specifically (unobfuscated, official Mojang mappings, no Yarn).
If you're on 1.21.11 or earlier instead, the vanilla class names throughout
`FileManagerFabricMod.java` need to go back to the old Yarn names
(`ServerPlayerEntity` instead of `ServerPlayer`, `ServerCommandSource`
instead of `CommandSourceStack`, `Text` instead of `Component`, etc.) and
`build.gradle` needs a `mappings` line again pointing at a Yarn build for
your target version.

## Architecture

Most of this plugin has zero platform dependency — the embedded HTTP(S)
server, all file/zip/console handlers, auth, and the entire web UI are
plain Java built on `com.sun.net.httpserver` (part of the JDK itself, no
external dependency). Only the "glue" — plugin entrypoint, command
registration, scheduling, and hooking into each platform's own console/event
system — is platform-specific.

```
kpe-filemanager-parent/            (aggregator pom)
├── kpe-filemanager-core/          (platform-agnostic, zero deps)
│   └── site.kpeclub.filemanager.core
│       ├── WebServer, TokenManager, RateLimiter, FileUtils
│       ├── ConsoleManager           (takes PlatformScheduler + CommandDispatcher — see below)
│       ├── ConsoleLogHandler
│       ├── PlatformScheduler        (interface each platform implements)
│       ├── CommandDispatcher        (interface each platform implements)
│       ├── SimpleYamlConfig         (tiny hand-rolled config.yml reader, used by
│       │                             Velocity/Fabric/Forge — none of them have a
│       │                             Bukkit-style config API, and pulling in
│       │                             snakeyaml just for a dozen settings felt
│       │                             like overkill)
│       ├── handlers/                (all the HTTP API handlers, incl. zip/unzip)
│       └── resources/web/           (index.html, app.js, style.css — shared UI)
├── kpe-filemanager-paper/          (Paper + Folia launcher)
│   └── site.kpeclub.filemanager.paper
│       ├── FileManagerPlugin        (JavaPlugin, /filemgr command, config.yml loading)
│       └── PlayerCommandListener    (PlayerCommandPreprocessEvent → cmd-history log)
├── kpe-filemanager-velocity/       (Velocity launcher, Maven)
│   └── site.kpeclub.filemanager.velocity
│       └── FileManagerVelocityPlugin  (@Plugin, /filemgr command, ProxyInitializeEvent)
├── kpe-filemanager-fabric/         (Fabric launcher, separate Gradle project — see below)
│   └── site.kpeclub.filemanager.fabric
│       └── FileManagerFabricMod       (DedicatedServerModInitializer, fabric-command-api-v2)
└── kpe-filemanager-forge/          (Forge launcher, separate Gradle project — see below)
    └── site.kpeclub.filemanager.forge
        └── FileManagerForgeMod         (@Mod, RegisterCommandsEvent)
```

`ConsoleManager` needs to schedule a periodic flush and dispatch console
commands, both of which are inherently platform-specific (Bukkit's
scheduler vs. Velocity's, `Bukkit.dispatchCommand` vs. Velocity's command
manager). Rather than let core depend on either, it takes two tiny
functional interfaces:

```java
public interface PlatformScheduler {
    void runRepeating(Runnable task, long initialDelayMs, long periodMs);
}
public interface CommandDispatcher {
    void dispatch(String command);
}
```

Each platform module supplies these as a couple of lines of lambda, e.g.
Paper's is a one-liner wrapping `Bukkit.getGlobalRegionScheduler()`
(Folia-compatible — see below), Velocity's wraps `server.getScheduler()`.

## Known platform differences worth knowing

- **Permissions on Velocity work differently than on Paper.** Paper/Bukkit
  has a built-in concept of OP with a `default: op` permission fallback.
  Velocity has no such built-in default — `kpe.filemanager.access` and
  `kpe.filemanager.reload` only resolve to *anything* if you have a
  permissions plugin (e.g. LuckPerms for Velocity) installed and grant
  them explicitly. Without one, nobody will pass the permission check.
- **Command visibility differs on a proxy.** On Paper,
  `PlayerCommandPreprocessEvent` sees every command a player runs. On
  Velocity, most gameplay commands are just forwarded straight through to
  whichever backend server the player is on — but Velocity still fires
  `CommandExecuteEvent` for all of them before routing, so the
  `cmd-history-*.txt` audit log is still complete either way.
- **`root-directory` means something different per platform.** On Paper,
  it's the Minecraft server's own directory (worlds, plugins, etc). On
  Velocity, it's the *proxy's* own directory (its config.yml, plugins/)
  — a proxy has no "world" to browse, but browsing/editing its own config
  and plugin jars is exactly as useful.

## Known limitation: PlugManX / hot-reloading the Paper module

`/plugman reload` and `/plugman load` do **not** work for the Paper module
on newer Paper builds — you'll see:

```
InvalidPluginException: Plugin didn't load any plugin providers?
```

This is a Paper-level limitation with hot-loading plugins at runtime after
server boot, not specific to this plugin — see
[this write-up](https://madelinemiller.dev/blog/problem-with-reload/) for
why. **Use a full server restart whenever you update the jar.** Config-only
changes don't need this — use `/filemgr reload` instead, which restarts
just this plugin's own internal web server, in-process, without asking
Paper to reload anything.

## Build

**Maven modules (core, Paper, Velocity):**

Requires JDK 17+ and Maven, with normal internet access (Paper's, Velocity's,
and Maven Central repos are all needed and aren't reachable from wherever
this was originally written).

```bash
mvn clean package
```

This builds core + Paper + Velocity. Jars land at:
- `kpe-filemanager-paper/target/kpe-filemanager.jar`
- `kpe-filemanager-velocity/target/kpe-filemanager-velocity.jar`

To build just one: `mvn clean package -pl kpe-filemanager-paper -am`
(the `-am` also builds core, which it depends on).

**Gradle modules (Fabric, Forge):**

These are deliberately **not** part of the Maven reactor above — Fabric
Loom and ForgeGradle aren't Maven plugins, so each lives in its own
standalone Gradle project. Build core first and install it to your local
Maven repo so Gradle can find it:

```bash
cd kpe-filemanager-core && mvn install && cd ..
cd kpe-filemanager-fabric && ./gradlew build && cd ..
cd kpe-filemanager-forge && ./gradlew build && cd ..
```

(No Gradle wrapper jar is included here — run `gradle wrapper` once in each
directory first if you don't already have Gradle installed globally.)

Remember these two haven't been build-tested at all — see the higher-risk
note above.

## Configure

Same `config.yml` format on both platforms (Velocity just reads it with its
own tiny parser instead of Bukkit's). After editing, run `/filemgr reload`
(in-game or from console/proxy console) to apply without a restart:

```yaml
port: 8080
bind-address: "0.0.0.0"       # 0.0.0.0 = reachable externally; use 127.0.0.1 if reverse-proxying
root-directory: ""            # "" = full server/proxy root
public-url: ""                # e.g. https://fm.kpeclub.site
token-expiry-minutes: 5
login-password: ""            # optional extra password after the link
session-expiry-hours: 12
max-edit-file-size-kb: 20480000
max-upload-size-mb: 512
console:
  max-lines: 400
https:
  enabled: false
  keystore-path: "keystore.jks"
  keystore-password: ""
  key-password: ""
```

See the comments in each module's `config.yml` for the full explanation,
including keystore setup for HTTPS.

## Security notes

- Only players/sources with `kpe.filemanager.access` can generate login
  links; `kpe.filemanager.reload` gates config reload separately.
- Login tokens are single-use, 256-bit random, and expire after
  `token-expiry-minutes`.
- Optional `login-password` adds a second factor: the link alone isn't
  enough if it leaks or gets screenshotted.
- Sessions are in-memory only and expire after `session-expiry-hours`. A
  logout button revokes a session immediately.
- Failed session checks, failed token redemptions, and failed passwords
  are rate-limited per IP (only failures count) and logged to the
  console/`console.txt`.
- Every response carries standard hardening headers (CSP, X-Frame-Options,
  nosniff, etc.), and the session cookie is `HttpOnly` + `SameSite=Strict`
  (+ `Secure` automatically when HTTPS is enabled).
- All file paths are canonicalized and checked against the configured root
  to block `../` path traversal — including inside zip extraction, which
  also has zip-bomb caps (2 GB / 50,000 entries).
- Uploads and file writes are capped so a request can't exhaust memory.
- The web server's thread pool and console log-hook are explicitly cleaned
  up on disable/restart — otherwise they'd leak the plugin's classloader on
  every reload.
