package site.kpeclub.filemanager.forge;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.MinecraftForge;
import site.kpeclub.filemanager.core.ConsoleManager;
import site.kpeclub.filemanager.core.SimpleYamlConfig;
import site.kpeclub.filemanager.core.TokenManager;
import site.kpeclub.filemanager.core.WebServer;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Forge launcher for the same core (WebServer, handlers, TokenManager,
 * ConsoleManager) the Paper/Velocity/Fabric modules use — see
 * kpe-filemanager-core.
 * <p>
 * WARNING: same caveat as the Fabric module — written without the ability
 * to compile-check against Forge's actual API or a real Forge dev
 * environment (no network access to Forge's Maven repo from where this was
 * built). The lifecycle/event patterns here (RegisterCommandsEvent,
 * ServerStartedEvent/ServerStoppingEvent, @Mod) match documented Forge
 * conventions as of the 1.20.x line, but Forge's API has shifted
 * significantly across versions (and NeoForge forked from it entirely) —
 * expect to need adjustments for whatever version you target.
 * <p>
 * Like Fabric, Forge has no built-in fine-grained permission system beyond
 * vanilla's numeric operator levels — this uses level 4 (same as /op,
 * /stop) for both kpe.filemanager.access and kpe.filemanager.reload.
 */
@Mod("kpefilemanager")
public class FileManagerForgeMod {

    private static final int OP_LEVEL = 4;

    private WebServer webServer;
    private TokenManager tokenManager;
    private ConsoleManager consoleManager;
    private ScheduledExecutorService scheduler;
    private MinecraftServer minecraftServer;
    private File dataFolder;

    private volatile String publicUrlBase;
    private volatile int port;
    private volatile boolean httpsEnabled;

    public FileManagerForgeMod() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onServerStarted(ServerStartedEvent event) {
        this.minecraftServer = event.getServer();
        this.dataFolder = new File(minecraftServer.getServerDirectory().toFile(), "kpefilemanager");
        this.webServer = new WebServer();
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "kpe-filemanager-scheduler");
            t.setDaemon(true);
            return t;
        });
        startServices(null);
    }

    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        if (webServer != null) webServer.stop();
        if (consoleManager != null) consoleManager.stop();
        if (scheduler != null) scheduler.shutdownNow();
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("filemgr")
                .executes(ctx -> runFilemgr(ctx.getSource(), new String[0]))
                .then(Commands.argument("args", StringArgumentType.greedyString())
                        .executes(ctx -> runFilemgr(ctx.getSource(),
                                StringArgumentType.getString(ctx, "args").split("\\s+")))));
        event.getDispatcher().register(Commands.literal("fm")
                .executes(ctx -> runFilemgr(ctx.getSource(), new String[0]))
                .then(Commands.argument("args", StringArgumentType.greedyString())
                        .executes(ctx -> runFilemgr(ctx.getSource(),
                                StringArgumentType.getString(ctx, "args").split("\\s+")))));
    }

    private int runFilemgr(CommandSourceStack source, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!source.hasPermission(OP_LEVEL)) {
                source.sendFailure(Component.literal("You do not have permission to reload the file manager."));
                return 0;
            }
            source.sendSuccess(() -> Component.literal("Reloading file manager config..."), false);
            scheduler.execute(() -> startServices(source));
            return 1;
        }

        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal(
                    "This command can only be used by a connected player. Use '/filemgr reload' from console to reload config."));
            return 0;
        }
        if (tokenManager == null) {
            source.sendFailure(Component.literal("The file manager is not ready yet, try again in a moment."));
            return 0;
        }
        if (!source.hasPermission(OP_LEVEL)) {
            source.sendFailure(Component.literal("You do not have permission to use the file manager."));
            return 0;
        }

        String token = tokenManager.generateLoginToken(player.getUUID(), player.getGameProfile().getName());
        String url = resolveBaseUrl() + "/?token=" + token;

        source.sendSuccess(() -> Component.literal("Your one-time file manager link (expires in a few minutes):"), false);
        source.sendSuccess(() -> Component.literal(url)
                .withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url))), false);
        return 1;
    }

    /** Same reload-without-restart approach as the other modules. */
    private boolean startServices(CommandSourceStack feedbackTo) {
        SimpleYamlConfig config;
        Path configPath = dataFolder.toPath().resolve("config.yml");
        try {
            Files.createDirectories(dataFolder.toPath());
            if (!Files.exists(configPath)) {
                try (var in = getClass().getResourceAsStream("/config.yml")) {
                    if (in != null) Files.copy(in, configPath);
                }
            }
            config = SimpleYamlConfig.load(configPath);
        } catch (Exception e) {
            System.err.println("[KPEFileManager] Failed to load config.yml: " + e.getMessage());
            config = new SimpleYamlConfig();
        }

        port = config.getInt("port", 8080);
        String bindAddress = config.getString("bind-address", "0.0.0.0");
        String rootDirConfig = config.getString("root-directory", "");
        long tokenExpiryMinutes = config.getLong("token-expiry-minutes", 5);
        long sessionExpiryHours = config.getLong("session-expiry-hours", 12);
        long maxEditFileSizeKb = config.getLong("max-edit-file-size-kb", 20480000);
        long maxUploadSizeMb = config.getLong("max-upload-size-mb", 512);
        int consoleMaxLines = config.getInt("console.max-lines", 400);
        String loginPassword = config.getString("login-password", "");
        publicUrlBase = config.getString("public-url", "");

        httpsEnabled = config.getBoolean("https.enabled", false);
        String keystorePathConfig = config.getString("https.keystore-path", "keystore.jks");
        String keystorePassword = config.getString("https.keystore-password", "");
        String keyPassword = config.getString("https.key-password", "");
        File keystoreFile = new File(keystorePathConfig);
        if (!keystoreFile.isAbsolute()) {
            keystoreFile = new File(dataFolder, keystorePathConfig);
        }

        File serverRoot = new File(System.getProperty("user.dir"));
        File root = rootDirConfig == null || rootDirConfig.isBlank()
                ? serverRoot
                : new File(serverRoot, rootDirConfig);
        if (!root.exists()) {
            root.mkdirs();
        }

        if (tokenManager == null) {
            tokenManager = new TokenManager(tokenExpiryMinutes, sessionExpiryHours);
        } else {
            tokenManager.updateExpiries(tokenExpiryMinutes, sessionExpiryHours);
        }

        if (consoleManager == null) {
            consoleManager = new ConsoleManager(
                    dataFolder,
                    consoleMaxLines,
                    (task, initialDelayMs, periodMs) -> scheduler.scheduleAtFixedRate(
                            task, initialDelayMs, periodMs, TimeUnit.MILLISECONDS),
                    // Dispatching a command touches game state, so it must run on the
                    // server thread — MinecraftServer#execute() queues it for next tick.
                    cmd -> minecraftServer.execute(() ->
                            minecraftServer.getCommands().performPrefixedCommand(
                                    minecraftServer.createCommandSourceStack(), cmd)),
                    msg -> System.err.println("[KPEFileManager] " + msg));
            consoleManager.start();
        } else {
            consoleManager.setMaxLines(consoleMaxLines);
        }

        try {
            webServer.start(bindAddress, port, root, tokenManager, sessionExpiryHours, maxEditFileSizeKb,
                    consoleManager, httpsEnabled, keystoreFile, keystorePassword, keyPassword, maxUploadSizeMb,
                    loginPassword);
            String summary = (httpsEnabled ? "https://" : "http://") + bindAddress + ":" + port
                    + " (root: " + root.getPath() + ")";
            System.out.println("[KPEFileManager] web server listening on " + summary);
            if (feedbackTo != null) {
                feedbackTo.sendSuccess(() -> Component.literal("File manager config reloaded — now serving " + summary), false);
            }
            return true;
        } catch (Exception e) {
            System.err.println("[KPEFileManager] Failed to start web server: " + e.getMessage());
            if (feedbackTo != null) {
                feedbackTo.sendFailure(Component.literal("Reload failed: " + e.getMessage()));
            }
            return false;
        }
    }

    private String resolveBaseUrl() {
        String defaultScheme = httpsEnabled ? "https://" : "http://";
        if (publicUrlBase != null && !publicUrlBase.isBlank()) {
            String base = publicUrlBase.trim();
            if (!base.startsWith("http://") && !base.startsWith("https://")) {
                base = defaultScheme + base;
            }
            return base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        }
        try {
            String host = InetAddress.getLocalHost().getHostAddress();
            return defaultScheme + host + ":" + port;
        } catch (UnknownHostException e) {
            return defaultScheme + "localhost:" + port;
        }
    }
}
