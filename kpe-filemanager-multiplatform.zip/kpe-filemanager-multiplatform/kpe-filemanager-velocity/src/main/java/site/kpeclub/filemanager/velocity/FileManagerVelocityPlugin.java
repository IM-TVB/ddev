package site.kpeclub.filemanager.velocity;

import com.google.inject.Inject;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.slf4j.Logger;
import site.kpeclub.filemanager.core.ConsoleManager;
import site.kpeclub.filemanager.core.TokenManager;
import site.kpeclub.filemanager.core.SimpleYamlConfig;
import site.kpeclub.filemanager.core.WebServer;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

/**
 * Velocity launcher for the same core (WebServer, handlers, TokenManager,
 * ConsoleManager) the Paper module uses — see kpe-filemanager-core.
 * <p>
 * One real behavior difference from Paper worth knowing: on a backend
 * server, PlayerCommandPreprocessEvent sees every command a player types.
 * On a proxy, most gameplay commands are just forwarded straight through to
 * whichever backend server the player is on — Velocity still fires
 * CommandExecuteEvent for all of them before deciding how to route, so the
 * cmd-history audit log here is still complete, but "console" in that sense
 * means the proxy's own console, not any backend server's.
 */
@Plugin(id = "kpefilemanager", name = "KPE File Manager", version = "1.0.2",
        description = "Web-based file manager for the proxy, OP-only access via in-game token.",
        authors = {"IM_TVB"})
public class FileManagerVelocityPlugin {

    private final ProxyServer server;
    private final Logger logger;
    private final Path dataDirectory;

    private WebServer webServer;
    private TokenManager tokenManager;
    private ConsoleManager consoleManager;
    private volatile String publicUrlBase;
    private volatile int port;
    private volatile boolean httpsEnabled;

    @Inject
    public FileManagerVelocityPlugin(ProxyServer server, Logger logger, @DataDirectory Path dataDirectory) {
        this.server = server;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        webServer = new WebServer();
        startServices(null);

        server.getCommandManager().register(
                server.getCommandManager().metaBuilder("filemgr").aliases("fm").build(),
                new FilemgrCommand());
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        if (webServer != null) {
            webServer.stop();
            logger.info("KPEFileManager web server stopped.");
        }
        if (consoleManager != null) {
            consoleManager.stop();
        }
    }

    @Subscribe(order = PostOrder.EARLY)
    public void onCommandExecute(CommandExecuteEvent event) {
        if (consoleManager == null) return;
        CommandSource source = event.getCommandSource();
        String who = (source instanceof Player p) ? p.getUsername() : "console";
        consoleManager.logPlayerCommand(who, "/" + event.getCommand());
    }

    /** Same reload-without-restart approach as the Paper module — see its startServices() for details. */
    private boolean startServices(CommandSource feedbackTo) {
        SimpleYamlConfig config;
        Path configPath = dataDirectory.resolve("config.yml");
        try {
            Files.createDirectories(dataDirectory);
            if (!Files.exists(configPath)) {
                try (var in = getClass().getResourceAsStream("/config.yml")) {
                    if (in != null) Files.copy(in, configPath);
                }
            }
            config = SimpleYamlConfig.load(configPath);
        } catch (Exception e) {
            logger.error("Failed to load config.yml: {}", e.getMessage());
            config = new SimpleYamlConfig();
        }

        port = config.getInt("port", 8080);
        String bindAddress = config.getString("bind-address", "0.0.0.0");
        String rootDirConfig = config.getString("root-directory", "");
        long tokenExpiryMinutes = config.getLong("token-expiry-minutes", 5);
        long sessionExpiryHours = config.getLong("session-expiry-hours", 12);
        long maxEditFileSizeKb = config.getLong("max-edit-file-size-kb", 20480000);
        long maxUploadSizeMb = config.getLong("max-upload-size-mb", 512);
        int consoleMaxLines = config.getInt("console.max-lines", 400);
        String loginPassword = config.getString("login-password", "");
        publicUrlBase = config.getString("public-url", "");

        httpsEnabled = config.getBoolean("https.enabled", false);
        String keystorePathConfig = config.getString("https.keystore-path", "keystore.jks");
        String keystorePassword = config.getString("https.keystore-password", "");
        String keyPassword = config.getString("https.key-password", "");
        File keystoreFile = new File(keystorePathConfig);
        if (!keystoreFile.isAbsolute()) {
            keystoreFile = new File(dataDirectory.toFile(), keystorePathConfig);
        }

        File serverRoot = new File(System.getProperty("user.dir"));
        File root = rootDirConfig == null || rootDirConfig.isBlank()
                ? serverRoot
                : new File(serverRoot, rootDirConfig);
        if (!root.exists()) {
            root.mkdirs();
        }

        if (tokenManager == null) {
            tokenManager = new TokenManager(tokenExpiryMinutes, sessionExpiryHours);
        } else {
            tokenManager.updateExpiries(tokenExpiryMinutes, sessionExpiryHours);
        }

        if (consoleManager == null) {
            consoleManager = new ConsoleManager(
                    dataDirectory.toFile(),
                    consoleMaxLines,
                    (task, initialDelayMs, periodMs) -> server.getScheduler()
                            .buildTask(this, task)
                            .delay(initialDelayMs, TimeUnit.MILLISECONDS)
                            .repeat(periodMs, TimeUnit.MILLISECONDS)
                            .schedule(),
                    cmd -> server.getCommandManager().executeAsync(server.getConsoleCommandSource(), cmd),
                    msg -> logger.warn(msg));
            consoleManager.start();
        } else {
            consoleManager.setMaxLines(consoleMaxLines);
        }

        try {
            webServer.start(bindAddress, port, root, tokenManager, sessionExpiryHours, maxEditFileSizeKb,
                    consoleManager, httpsEnabled, keystoreFile, keystorePassword, keyPassword, maxUploadSizeMb,
                    loginPassword);
            String summary = (httpsEnabled ? "https://" : "http://") + bindAddress + ":" + port
                    + " (root: " + root.getPath() + ")";
            logger.info("KPEFileManager web server listening on {}", summary);
            if (feedbackTo != null) {
                feedbackTo.sendMessage(Component.text("File manager config reloaded — now serving " + summary, NamedTextColor.GREEN));
            }
            return true;
        } catch (Exception e) {
            logger.error("Failed to start web server: {}", e.getMessage());
            if (httpsEnabled) {
                logger.error("Check https.keystore-path / https.keystore-password / https.key-password in config.yml.");
            }
            if (feedbackTo != null) {
                feedbackTo.sendMessage(Component.text("Reload failed: " + e.getMessage(), NamedTextColor.RED));
            }
            return false;
        }
    }

    private String resolveBaseUrl() {
        String defaultScheme = httpsEnabled ? "https://" : "http://";
        if (publicUrlBase != null && !publicUrlBase.isBlank()) {
            String base = publicUrlBase.trim();
            if (!base.startsWith("http://") && !base.startsWith("https://")) {
                base = defaultScheme + base;
            }
            return base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        }
        try {
            String host = InetAddress.getLocalHost().getHostAddress();
            return defaultScheme + host + ":" + port;
        } catch (UnknownHostException e) {
            return defaultScheme + "localhost:" + port;
        }
    }

    private class FilemgrCommand implements SimpleCommand {

        @Override
        public void execute(Invocation invocation) {
            CommandSource source = invocation.source();
            String[] args = invocation.arguments();

            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (!source.hasPermission("kpe.filemanager.reload")) {
                    source.sendMessage(Component.text("You do not have permission to reload the file manager.", NamedTextColor.RED));
                    return;
                }
                source.sendMessage(Component.text("Reloading file manager config...", NamedTextColor.GRAY));
                server.getScheduler().buildTask(FileManagerVelocityPlugin.this,
                        () -> startServices(source)).schedule();
                return;
            }

            if (!(source instanceof Player player)) {
                source.sendMessage(Component.text(
                        "This command can only be used by a connected player. Use '/filemgr reload' from console to reload config."));
                return;
            }
            if (tokenManager == null) {
                player.sendMessage(Component.text("The file manager is not ready yet, try again in a moment.", NamedTextColor.RED));
                return;
            }
            if (!player.hasPermission("kpe.filemanager.access")) {
                player.sendMessage(Component.text("You do not have permission to use the file manager.", NamedTextColor.RED));
                return;
            }

            String token = tokenManager.generateLoginToken(player.getUniqueId(), player.getUsername());
            String url = resolveBaseUrl() + "/?token=" + token;

            player.sendMessage(Component.text("Your one-time file manager link (expires in a few minutes):", NamedTextColor.AQUA));
            player.sendMessage(Component.text(url, NamedTextColor.GREEN).clickEvent(ClickEvent.openUrl(url)));
        }

        @Override
        public boolean hasPermission(Invocation invocation) {
            return true; // fine-grained checks happen in execute(), matching the Paper module's pattern
        }
    }
}
